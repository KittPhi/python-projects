#######################################################################################################################
"""
Use this code block to determine the Operating System and import packages that are installed in the directory of this
script.

Usage: In order to install Python packages to a directory named lib in current directory
    1. mkdir -p lib (mdir lib)
    2. cd lib
    3. pip install -t ./ package_name

"""
import platform
import sys
import os

# dir_path = os.path.dirname(os.path.realpath(__file__))
#
# if platform.system() == "Linux":
#     sys.path.append(dir_path + "/lib")
# if platform.system() == "Windows":
#     sys.path.append(dir_path + "\lib")
sys.path.append("/home/jmiller/repos/motion-analysis/lib")
"""
End of block
"""
#######################################################################################################################

import cv2
import csv
import wrnchAI
import time
import json
import asyncio
import boto3

# sys.path.append('helpers')
from helpers.visualizer import Visualizer
from helpers.utils import videocapture_context
from helpers.plotJoints import plotJoints
from helpers.checkValidCameraIndex import checkValidCameraIndex
from helpers.wrnchKey import *
from helpers.gernerateCsv import generateCsv
from helpers.mqtt_publish import *
from helpers.joint_labels import *
from helpers.s3_write import write_to_s3

client = boto3.client('iot-data')

def handler(event, context):
    wrnch_key = getWrchKey()
    models_path = "/usr/bin/wrModels"


    # todo: detect realsense index
    # camera_indexes = checkValidCameraIndex()  # list of camera indexes
    camera_index = 0

    # todo: fix video save, see line 156
    # Define the codec and create VideoWriter object
    # fourcc = cv2.VideoWriter_fourcc('h', '2', '6', '4')
    # fourcc = cv2.VideoWriter_fourcc(*'X264')
    # fps = 20.0
    # resolution = (640, 480)
    # video_out = cv2.VideoWriter(test_time + '_output.mkv', fourcc, fps, resolution)

    # todo input from event
    user = "john"
    test_time = time.strftime('%l.%M%p_%b_%d_%Y')
    # test time has a leading space
    test_time = str(test_time)[1:]
    output_path = "/tmp/data/{}/{}/".format(user, test_time)
    frames_number = 200
    testTimeLength = 5
    test_type = 'chair'
    serial_number = 123
    topic = 'joints/{}'.format(str(serial_number))


    joints_filename = str(test_time) + "_joints.csv"
    confidence_filename = str(test_time) + "_confidence_joints.csv"
    confidence_human_filename = str(test_time) + "_confidence_human.csv"

    # dictionary that will be saved as a json of the payloads
    big_payload = {}


    # payload to indicate starting
    payload = {
        'start_test': True,
        'test_time': test_time,
        'user': user,
        'output_path': output_path,
        'length_of_test': testTimeLength,
        'test_type': test_type,
        'serial_number': serial_number,
    }
    publish_mqtt(json.dumps(payload), topic)

    ### SETUP WRNCH
    # not sure if this will work
    # code = wrnchAI.license_check_string(wrnch_key_value) if wrnch_key_value \
    #     else wrnchAI.license_check()
    # if code != 0:
    #     raise RuntimeError(wrnchAI.returncode_describe(code))

    params = wrnchAI.PoseParams()
    params.bone_sensitivity = wrnchAI.Sensitivity.high
    params.joint_sensitivity = wrnchAI.Sensitivity.high
    params.enable_tracking = True

    # Default Model resolution
    params.preferred_net_width = 328
    params.preferred_net_height = 184

    output_format = wrnchAI.JointDefinitionRegistry.get('j25')
    estimator = wrnchAI.PoseEstimator(models_path=models_path,
                                      license_string=wrnch_key,
                                      params=params,
                                      gpu_id=0,
                                      output_format=output_format)

    options = wrnchAI.PoseEstimatorOptions()

    video_index = int(camera_index)
    with videocapture_context(video_index) as cap:
        
        # wrnch
        # visualizer = Visualizer()
        joint_definition = estimator.human_2d_output_format()
        bone_pairs = joint_definition.bone_pairs()

        # time record starts
        startTime = time.time()

        generateCsv(output_path, joints_filename, confidence_filename, confidence_human_filename)

        counter = 0
        while True:
            _, frame = cap.read()

            # currently not needed
            # # dimensions of frame
            # width = frame.shape[1]
            # height = frame.shape[0]
            # # frame counter
            # counter += 1

            if frame is not None:
                # wrnch
                estimator.process_frame(frame, options)
                humans2d = estimator.humans_2d()
                # visualizer.draw_image(frame)

                image_time = time.time()

                # todo: if len(humans2d)==0, this will break
                human = humans2d[0]
                # for human in humans2d:
                joints = human.joints()
                confidenceScores = human.scores()
                confidence = human.score()

                # todo: make this an async function with threading, OR buffer and publish at the end
                if len(joints) >= 1:
                    # publish data to mqtt
                    # send a dictionary that zips joints_labels and timetamp + joints
                    joints_dict = dict(zip(joints_labels(), [image_time - startTime] + joints.tolist()))
                    joints_confidence_dict = dict(zip(joints_labels(),[image_time - startTime] + confidenceScores.tolist()))
                    # human_confidence_dict = dict(zip(confidence_labels(), [image_time - startTime] + confidence.tolist()))
                    payload = {
                        'start_test': False,
                        'test_time' : test_time,
                        'user' : user,
                        'output_path' : output_path,
                        'length_of_test' : testTimeLength,
                        'test_type' : test_type,
                        'serial_number' : serial_number,
                        'joints' : joints_dict,
                        'joints_confidence' : joints_confidence_dict,
                        'human_confidence' : confidence
                    }

                    """
                    This seems to be slowing down record time
                    """
                    # todo: make async
                    # publish payload
                    # publish_mqtt(json.dumps(payload), topic)

                    # save payload to to big_payload
                    big_payload[image_time] = payload

                    # write dcata to csv
                    with open(output_path + joints_filename, 'a') as realTimeCSV:
                        csvWriter = csv.writer(realTimeCSV)
                        csvWriter.writerow(
                            [image_time - startTime] + joints.tolist())


                    with open(output_path + confidence_filename, 'a') as realTimeConfidenceCSV:
                        csvWriter = csv.writer(
                            realTimeConfidenceCSV)
                        csvWriter.writerow(
                            [image_time - startTime] + confidenceScores.tolist())


                    with open(output_path + confidence_human_filename, 'a') as realTimeHumanCSV:
                        csvWriter = csv.writer(realTimeHumanCSV)
                        csvWriter.writerow(
                            [image_time - startTime] + [str(confidence)])

                    # wrnch
                    # visualizer.draw_points(joints)
                    # visualizer.draw_lines(joints, bone_pairs)

                # todo: Fix the video output
                # save the video
                # video_out = cv2.VideoWriter(output_path + 'motion_analysis.mp4', fourcc, fps, resolution)
                # video_out = cv2.VideoWriter(output_path + 'output.avi', -1, 20.0, (640, 480)) # this one might work - tested in windows
                # video_out.write(frame)

                # wrnch
                # visualizer.show()

            if time.time() - startTime >= testTimeLength:

                # todo: remove plots before deploying
                plotJoints(output_path, joints_filename,
                           confidence_filename, confidence_human_filename)

                # write_to_s3(bucket_name="motion-analysis", file_name=output_path + joints_filename)

                publish_mqtt(json.dumps(big_payload), topic)


                break

if __name__ == '__main__':
    handler('', '')