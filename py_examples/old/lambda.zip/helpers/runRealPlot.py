#######################################################################################################################
"""
Use this code block to determine the Operating System and import packages that are installed in the directory of this
script.

Usage: In order to install Python packages to a directory named lib in current directory
    1. mkdir -p lib (mdir lib)
    2. cd lib
    3. pip install -t ./ package_name

"""
import platform
import sys
import os

sys.path.append("/home/jmiller/repos/motion-analysis/lib")
# dir_path = os.path.dirname(os.path.realpath(__file__))
#
# if platform.system() == "Linux":
#     sys.path.append(dir_path + "/lib")
# if platform.system() == "Windows":
#     sys.path.append(dir_path + "\lib")


"""
End of block
"""
#######################################################################################################################

import pathlib
import threading
from pandas import pandas as pd
from matplotlib import pyplot as plt
from matplotlib.animation import FuncAnimation


class plotFuntion(object):
    """ Threading example class
    The run() method will be started and it will run in the background
    until the application exits.
    """

    def __init__(self, path):
        self.path = path
        thread = threading.Thread(target=self.run, args=())
        thread.daemon = True                            # Daemonize thread
        thread.start()                                  # Start the execution

    def run(self):
        """ Method that runs forever """
        # x_border = [0, 640, 640, 0, 0]
        # y_border = [0, 0, 480, 480, 0]
        x_border = [0, 1, 1, 0, 0]
        y_border = [0, 0, 1, 1, 0]
        print(self.path)
        # print("self.path")
        file = pathlib.Path(self.path)
        outPath = self.path

        def animate(self):
            data = pd.read_csv(outPath)
            # print(data)
            time = data['time (s)']
            rwrist_X = data['rwrist_x']
            rwrist_X_1 = 1 - rwrist_X
            # print(neck_x)
            rwrist_Y = data['rwrist_y']
            rwrist_Y_1 = 1 - rwrist_Y

            lwrist_X = data['lwrist_x']
            lwrist_X_1 = 1 - lwrist_X
            # print(neck_x)
            lwrist_Y = data['lwrist_y']
            lwrist_Y_1 = 1 - lwrist_Y

            neck_x = data['neck_x']
            neck_y = data['neck_y']
            neck_y_1 = 1 - neck_y

            plt.cla()
            # y_scaler_x = [time[0], time[0]]
            # y_scaler_y = [1, 0]

            # plt.plot(x_border,y_border)
            # plt.plot(lwrist_X_1, lwrist_Y_1)
            plt.plot(time, neck_y_1, label='Neck, Y(t)')
            plt.tight_layout()
        if file.exists() == True:
            ani = FuncAnimation(plt.gcf(), animate, interval=250)
            # plt.plot(x_border, y_border, 'k')
            plt.cla()
            plt.show()
            plt.legend(loc='upper left')
            plt.savefig(path + "figure.png")
        else:
            print('runRealPlot.py cant find output file')
