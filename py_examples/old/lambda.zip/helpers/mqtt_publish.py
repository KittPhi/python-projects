#######################################################################################################################
"""
Use this code block to determine the Operating System and import packages that are installed in the directory of this
script.

Usage: In order to install Python packages to a directory named lib in current directory
    1. mkdir -p lib (mdir lib)
    2. cd lib
    3. pip install -t ./ package_name

"""
import platform
import sys
import os
sys.path.append("/home/jmiller/repos/motion-analysis/lib")
# dir_path = os.path.dirname(os.path.realpath(__file__))
#
# if platform.system() == "Linux":
#     sys.path.append(dir_path + "/../lib")
# if platform.system() == "Windows":
#     sys.path.append(dir_path + "\lib")

"""
End of block
"""
#######################################################################################################################


import csv
import boto3
import json
import pandas as pd
import asyncio
# from concurrent.futures import ProcessPoolExecutor
import concurrent.futures

executor = concurrent.futures.ProcessPoolExecutor(2)

# client = boto3.client('iot-data')

def publish_mqtt(payload, topic):
    # loop = asyncio.get_running_loop()
    client = boto3.client('iot-data')
    # payload = json.dumps(payload)
    print(payload)
    # print(json.dumps({payload[0] : payload[1:]}))
    # payload = {'hello':'world'}
    publish = client.publish(
        topic=topic,
        qos=1,
        payload=payload
    )
    # with concurrent.futures.ThreadPoolExecutor() as pool:
    #     result = await loop.run_in_executor(
    #         pool, publish)


def mqtt_publish_csv(file_name_1, file_name_2, file_name_3, metadata, topic):
    client = boto3.client('iot-data')

    # data = pd.read_csv(file_name_1)
    # print(data)
    # # for df in pd.read_csv(file_name_1,sep=',', header = None, chunksize=1):
    # with open(file_name_1) as f:
    #     # lines = [line.rstrip() for line in f]
    #     lines = f.readlines()
    # print(lines)
    with open(file_name_1) as f:
        records = csv.DictReader(f)
        for row in records:
            print(list(row))
    # payload = [data[i:i+100] for i in range(0, len(data), 100)]
    # for line in payload:
    #
    #     client.publish(
    #         topic=topic,
    #         qos=1,
    #         payload=line
    #     )






if __name__ == '__main__':
    # write_to_s3(file_name="realTime.csv")
    # publish_mqtt()
    mqtt_publish_csv("/tmp/john/10.56PM_May_04_2020/10.56PM_May_04_2020_joints.csv",
                     "/tmp/john/10.56PM_May_04_2020/10.56PM_May_04_2020_confidence_joints.csv",
                     "/tmp/john/10.56PM_May_04_2020/10.56PM_May_04_2020_confidence_human.csv",
                     "{'key':'value'}",
                     "joints/123")
    # stuff("realTime.csv")