
#######################################################################################################################
"""
Use this code block to determine the Operating System and import packages that are installed in the directory of this
script.

Usage: In order to install Python packages to a directory named lib in current directory
    1. mkdir -p lib (mdir lib)
    2. cd lib
    3. pip install -t ./ package_name

"""
import platform
import sys
import os
sys.path.append("/home/jmiller/repos/motion-analysis/lib")
# dir_path = os.path.dirname(os.path.realpath(__file__))
#
# if platform.system() == "Linux":
#     sys.path.append(dir_path + "/lib")
# if platform.system() == "Windows":
#     sys.path.append(dir_path + "\lib")


"""
End of block
"""
#######################################################################################################################

import pandas as pd
import matplotlib.pyplot as plt



def plotJoints(outPath, joints_filename, confidence_filename, confidence_human_filename):
    data = pd.read_csv(outPath + joints_filename)
    confidenceData = pd.read_csv(outPath + confidence_filename)
    humanConfidenceData = pd.read_csv(outPath + confidence_human_filename)

    humanConfidence = {
        'time_s': humanConfidenceData['time_s'],
        'confidence': humanConfidenceData['confidence']
    }

    confidence = {
        # 'time_s': confidenceData['time_s'],
        'rankle': confidenceData['rankle'],
        'rknee': confidenceData['rknee'],
        'rhip': confidenceData['rhip'],
        'lhip': confidenceData['lhip'],
        'lknee': confidenceData['lknee'],
        'lankle': confidenceData['lankle'],
        'pelv': confidenceData['pelv'],
        'thrx': confidenceData['thrx'],
        'neck': confidenceData['neck'],
        'head': confidenceData['head'],
        'rwrist': confidenceData['rwrist'],
        'relbow': confidenceData['relbow'],
        'rshoulder': confidenceData['rshoulder'],
        'lshoulder': confidenceData['lshoulder'],
        'lelbow': confidenceData['lelbow'],
        'lwrist': confidenceData['lwrist'],
        'nose': confidenceData['nose'],
        'reye': confidenceData['reye'],
        'rear': confidenceData['rear'],
        'leye': confidenceData['leye'],
        'lear': confidenceData['lear'],
        'rtoe': confidenceData['rtoe'],
        'ltoe': confidenceData['ltoe'],
        'rheel': confidenceData['rheel'],
        'lheel': confidenceData['lheel']
    }
    joints = {
        'time_s': data['time_s'],
        'rankle_x': 1 - data['rankle_x'],
        'rankle_y': 1 - data['rankle_y'],
        'rknee_x': 1 - data['rknee_x'],
        'rknee_y': 1 - data['rknee_y'],
        'rhip_x': 1 - data['rhip_x'],
        'rhip_y': 1 - data['rhip_y'],
        'lhip_y': 1 - data['lhip_y'],
        'lhip_x': 1 - data['lhip_x'],
        'lknee_x': 1 - data['lknee_x'],
        'lknee_y': 1 - data['lknee_y'],
        'lankle_x': 1 - data['lankle_x'],
        'lankle_y': 1 - data['lankle_y'],
        'pelv_x': 1 - data['pelv_x'],
        'pelv_y': 1 - data['pelv_y'],
        'thrx_x': 1 - data['thrx_x'],
        'thrx_y': 1 - data['thrx_y'],
        'neck_x': 1 - data['neck_x'],
        'neck_y': 1 - data['neck_y'],
        'head_x': 1 - data['head_x'],
        'head_y': 1 - data['head_y'],
        'rwrist_x': 1 - data['rwrist_x'],
        'rwrist_y': 1 - data['rwrist_y'],
        'relbow_x': 1 - data['relbow_x'],
        'relbow_y': 1 - data['relbow_y'],
        'rshoulder_x': 1 - data['rshoulder_x'],
        'rshoulder_y': 1 - data['rshoulder_y'],
        'lshoulder_x': 1 - data['lshoulder_x'],
        'lshoulder_y': 1 - data['lshoulder_y'],
        'lelbow_x': 1 - data['lelbow_x'],
        'lelbow_y': 1 - data['lelbow_y'],
        'lwrist_x': 1 - data['lwrist_x'],
        'lwrist_y': 1 - data['lwrist_y'],
        'nose_x': 1 - data['nose_x'],
        'nose_y': 1 - data['nose_y'],
        'reye_x': 1 - data['reye_x'],
        'reye_y': 1 - data['reye_y'],
        'rear_x': 1 - data['rear_x'],
        'rear_y': 1 - data['rear_y'],
        'leye_x': 1 - data['leye_x'],
        'leye_y': 1 - data['leye_y'],
        'lear_x': 1 - data['lear_x'],
        'lear_y': 1 - data['lear_y'],
        'rtoe_x': 1 - data['rtoe_x'],
        'rtoe_y': 1 - data['rtoe_y'],
        'ltoe_x': 1 - data['ltoe_x'],
        'ltoe_y': 1 - data['ltoe_y'],
        'rheel_x': 1 - data['rheel_x'],
        'rheel_y': 1 - data['rheel_y'],
        'lheel_x': 1 - data['lheel_x'],
        'lheel_y': 1 - data['lheel_y']
    }

    # plt.cla()

    # neck_y
    plt.figure(figsize=(15, 10))
    plt.subplot(4, 2, 3)
    plt.title('Motion Analysis of Joints')
    plt.plot(joints['time_s'], joints['neck_y'],
             label='{}, Y(t)'.format('Neck'))
    plt.xlabel('Time in seconds')
    plt.ylabel('{} position'.format('Neck'))
    plt.legend(loc='upper left')

    # center of mass
    plt.subplot(4, 2, 1)
    plt.plot(joints['time_s'], (joints['neck_y'] + joints['thrx_y'] + joints['pelv_y'])/3,
             label='{}, Y(t)'.format('Center of Mass'))
    plt.xlabel('Time in seconds')
    plt.ylabel('{} position'.format('Center of Mass'))
    plt.legend(loc='upper left')

    # pelv_y
    plt.subplot(4, 2, 5)
    plt.plot(joints['time_s'], joints['pelv_y'], 'm',
             label='{}, Y(t)'.format('Pelvis'))
    plt.xlabel('Time in seconds')
    plt.ylabel('{} position'.format('Pelvis'))
    plt.legend(loc='upper left')

    # 'thrx_y'
    plt.subplot(4, 2, 7)
    plt.plot(joints['time_s'], joints['thrx_y'], 'g',
             label='{}, Y(t)'.format('Thorax'))
    plt.xlabel('Time in seconds')
    plt.ylabel('{} position'.format('Thorax'))
    plt.legend(loc='upper left')

    # neck_y confidence
    plt.subplot(4, 2, 2)
    plt.title('Confidence of Joints')
    plt.plot(joints['time_s'], confidence['neck'],
             label='{} position confidence, C(t)'.format('Neck'))
    plt.xlabel('Time in seconds')
    plt.ylabel('{} position confidence'.format('Neck'))
    plt.legend(loc='upper left')

    # pelv_y confidence
    plt.subplot(4, 2, 4)
    plt.plot(joints['time_s'], confidence['pelv'], 'm',
             label='{} position confidence, C(t)'.format('Pelvis'))
    plt.xlabel('Time in seconds')
    plt.ylabel('{} position confidence'.format('Pelvis'))
    plt.legend(loc='upper left')

    # 'thrx_y' confidence
    plt.subplot(4, 2, 6)
    plt.plot(joints['time_s'], confidence['thrx'], 'g',
             label='{} position confidence, C(t)'.format('Thorax'))
    plt.xlabel('Time in seconds')
    plt.ylabel('{} position confidence'.format('Thorax'))
    plt.legend(loc='upper left')

    plt.subplot(4, 2, 8)
    plt.plot(joints['time_s'], humanConfidence['confidence'], 'g',
             label='Confidence of {}, C(t)'.format('Human'))
    plt.xlabel('Time in seconds')
    plt.ylabel('Human Confidence')
    plt.legend(loc='upper left')

    # plot and save
    plt.tight_layout()
    plt.draw()
    plt.gcf()
    plt.savefig(outPath + "motion-analysis.png")
    # plt.show()


if __name__ == '__main__':
    plotJoints('./outputDir/pose2d_1582648422.7533264/',
               'realTime.csv', 'realTimeConfidence.csv', 'realTimeConfidence_human.csv')
