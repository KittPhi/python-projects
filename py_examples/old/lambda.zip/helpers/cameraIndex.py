from os import listdir
import fnmatch

### return a list of all camera indexes

def cameraIndex():
    path = "/dev"
    all_files = listdir(path)
    pattern = 'video*'
    matching = fnmatch.filter(all_files, pattern)

    return [i for i in range(len(matching))]
