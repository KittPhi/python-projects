

def getWrchKey():
    with open("helpers/serial.txt", "r") as file:
        serial = file.read()
    return str(serial)

def updateSerial(new_serial):
    with open("serial.txt", "w") as file:
        file.write(new_serial)