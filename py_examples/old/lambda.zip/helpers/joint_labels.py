

def joints_labels():

    joints_labels = ['time_s',
                     'rankle_x', 'rankle_y',
                     'rknee_x', 'rknee_y',
                     'rhip_x', 'rhip_y',
                     'lhip_x', 'lhip_y',
                     'lknee_x', 'lknee_y',
                     'lankle_x', 'lankle_y',
                     'pelv_x', 'pelv_y',
                     'thrx_x', 'thrx_y',
                     'neck_x', 'neck_y',
                     'head_x', 'head_y',
                     'rwrist_x', 'rwrist_y',
                     'relbow_x', 'relbow_y',
                     'rshoulder_x', 'rshoulder_y',
                     'lshoulder_x', 'lshoulder_y',
                     'lelbow_x', 'lelbow_y',
                     'lwrist_x', 'lwrist_y',
                     'nose_x', 'nose_y',
                     'reye_x', 'reye_y',
                     'rear_x', 'rear_y',
                     'leye_x', 'leye_y',
                     'lear_x', 'lear_y',
                     'rtoe_x', 'rtoe_y',
                     'ltoe_x', 'ltoe_y',
                     'rheel_x', 'rheel_y',
                     'lheel_x', 'lheel_y']
    return joints_labels




def confidence_labels():

    confidence_labels = [
        'time_s',
        'rankle',
        'rknee',
        'rhip',
        'lhip',
        'lknee',
        'lankle',
        'pelv',
        'thrx',
        'neck',
        'head',
        'rwrist',
        'relbow',
        'rshoulder',
        'lshoulder',
        'lelbow',
        'lwrist',
        'nose',
        'reye',
        'rear',
        'leye',
        'lear',
        'rtoe',
        'ltoe',
        'rheel',
        'lheel']
    return confidence_labels