#######################################################################################################################
"""
Use this code block to determine the Operating System and import packages that are installed in the directory of this
script.

Usage: In order to install Python packages to a directory named lib in current directory
    1. mkdir -p lib (mdir lib)
    2. cd lib
    3. pip install -t ./ package_name

"""
import platform
import sys
import os
sys.path.append("/home/jmiller/repos/motion-analysis/lib")
# dir_path = os.path.dirname(os.path.realpath(__file__))
#
# if platform.system() == "Linux":
#     sys.path.append(dir_path + "/lib")
# if platform.system() == "Windows":
#     sys.path.append(dir_path + "\lib")

"""
End of block
"""
#######################################################################################################################

import boto3


def write_to_s3(bucket_name="motion-analysis", file_name=None):
    s3 = boto3.resource('s3')
    with open(file_name , 'rb') as data:
        print(file_name)
        print(data)
        s3.Bucket(bucket_name).put_object(Key=file_name, Body=data)