#######################################################################################################################
"""
Use this code block to determine the Operating System and import packages that are installed in the directory of this
script.

Usage: In order to install Python packages to a directory named lib in current directory
    1. mkdir -p lib (mdir lib)
    2. cd lib
    3. pip install -t ./ package_name

"""
import platform
import sys
import os

# dir_path = os.path.dirname(os.path.realpath(__file__))
#
# if platform.system() == "Linux":
#     sys.path.append(dir_path + "/lib")
# if platform.system() == "Windows":
#     sys.path.append(dir_path + "\lib")

sys.path.append("/home/jmiller/repos/motion-analysis/lib")
"""
End of block
"""
#######################################################################################################################

import cv2
from helpers.cameraIndex import cameraIndex

def checkValidCameraIndex(list_of_indexes=cameraIndex()):

    valid_index = []

    for index in list_of_indexes:
        try:
            cap = cv2.VideoCapture(index)
            if not cap.read()[0]:
                pass
            else:
                valid_index.append(index)
            cap.release()
        except:
            pass
    return str(valid_index)

# print(checkValidCameraIndex())